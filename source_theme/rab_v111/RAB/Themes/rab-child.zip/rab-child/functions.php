<?php
/**
 * This file is kept blank because we haven't used the parent themes style.css
 * file. It's only kept there to make the WordPress theme recognizable
 * =======================
 * Only for Developers
 * =======================
 */