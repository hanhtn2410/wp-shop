<?php
if( ! defined( 'ABSPATH' ) ) {
	exit; // exit if accessed directly
}

require_once 'rab_single_product.php';
require_once 'vc_map.php';