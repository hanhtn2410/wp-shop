<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

/**
 * Class WPBakeryShortCode_VC_Icon
 * @since 4.4
 */
class WPBakeryShortCode_VC_Icon extends WPBakeryShortCode {
}
