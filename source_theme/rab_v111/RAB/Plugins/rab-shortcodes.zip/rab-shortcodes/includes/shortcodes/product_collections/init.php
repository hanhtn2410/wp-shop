<?php
/**
 * Product Collections Shortcode
 */

if( ! defined( 'ABSPATH' ) ) {
	exit; // exit if accessed directly
}

require_once 'product_collections.php';
require_once 'vc_map.php';