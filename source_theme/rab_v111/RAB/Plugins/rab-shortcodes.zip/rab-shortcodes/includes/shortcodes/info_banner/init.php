<?php
if( ! defined( 'ABSPATH' ) ) {
	exit; // exit if accessed directly
}

require_once 'info_banner.php';
require_once 'vc_map.php';