<?php
if( ! defined( 'ABSPATH' ) ) {
	exit; // exit if accessed directly
}

require_once 'rab_products.php';
require_once 'vc_map.php';