<?php
if( function_exists( 'rab_social_share' ) ) {
	rab_social_share();
}