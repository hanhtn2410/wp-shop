<?php
if( ! defined( 'ABSPATH' ) ) {
	exit; // exit if accessed directly
}

require_once 'flash_sale.php';
require_once 'vc_map.php';